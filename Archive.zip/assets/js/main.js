$(".btn1").click (function () {
  $(".pizzainfo").toggle ();
});